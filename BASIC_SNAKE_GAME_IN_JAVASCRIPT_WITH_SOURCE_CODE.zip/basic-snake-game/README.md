# basic-snake-game
A basic snake game made with HTML canvas and some Javascript magic

## Usage
Just clone this repo and open the index.html in any browser (I don't think it'll work on Netscape tho lmao)
